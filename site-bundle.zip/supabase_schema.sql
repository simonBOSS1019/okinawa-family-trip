create extension if not exists pgcrypto;
create table public.trips (
 id uuid primary key default gen_random_uuid(), slug text unique not null, title text not null,
 start_date date not null, end_date date not null, party_adults int not null default 4,
 party_children int not null default 1, public_read boolean not null default true,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.trip_days (
 id uuid primary key default gen_random_uuid(), trip_id uuid not null references public.trips(id) on delete cascade,
 day_number int not null, trip_date date not null, title text not null, summary text,
 lodging_name text, route_name text, route_query text, sort_order int not null default 0,
 updated_at timestamptz not null default now(), unique(trip_id,day_number)
);
create table public.trip_stops (
 id uuid primary key default gen_random_uuid(), trip_day_id uuid not null references public.trip_days(id) on delete cascade,
 sort_order int not null default 0, start_time text, end_time text, place_name text not null,
 notes text, maps_url text, status text not null default '待確認', updated_at timestamptz not null default now()
);
create table public.trip_lodgings (
 id uuid primary key default gen_random_uuid(), trip_id uuid not null references public.trips(id) on delete cascade,
 lodging_name text not null, check_in date, check_out date, address text, maps_url text, notes text
);
create table public.trip_change_log (
 id uuid primary key default gen_random_uuid(), trip_id uuid not null references public.trips(id) on delete cascade,
 changed_by uuid, change_summary text not null, before_data jsonb, after_data jsonb,
 created_at timestamptz not null default now()
);
-- Production checklist:
-- Enable RLS on all tables.
-- Anonymous visitors may SELECT only public trip data.
-- Only the authenticated owner/admin may INSERT/UPDATE/DELETE.
-- Do not expose service-role keys in frontend code.
-- ChatGPT writes must go through an authenticated Edge Function/API, validate patches,
-- compare changed fields, and append a row to trip_change_log.
